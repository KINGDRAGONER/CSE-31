
#include <stdio.h>
#include <stdlib.h>

int **matMult(int **a, int **b, int size)
{
    // (4) Implement your matrix multiplication here. You will need to create a new matrix to store the product.
    int **result = (int **)malloc(size * sizeof(int *));
    for (int i = 0; i < size; i++)
    {
        result[i] = (int *)malloc(size * sizeof(int));
    }

    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            *((*(result + i)) + j) = 0;
            for (int k = 0; k < size; k++)
            {
                *((*(result + i)) + j) += *((*(a + i)) + k) * *((*(b + k)) + j);
            }
        }
    }

    return result;
}

void printArray(int **arr, int n)
{
    // (2) Implement your printArray function here
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%d ", *((*(arr + i)) + j));
        }
        printf("\n");
    }
}

int main()
{
    int n = 3;
    int **matA, **matB, **matC;
    // (1) Define 2 (n x n) arrays (matrices).
    int **matrix1 = (int **)malloc(n * sizeof(int *));
    int **matrix2 = (int **)malloc(n * sizeof(int *));

    for (int i = 0; i < n; i++)
    {
        matrix1[i] = (int *)malloc(n * sizeof(int));
        matrix2[i] = (int *)malloc(n * sizeof(int));
        for (int j = 0; j < n; j++)
        {
            *((*(matrix1 + i)) + j) = i * j;
            *((*(matrix2 + i)) + j) = 2*i * j;
        }
    }

    // (3) Call printArray to print out the 2 arrays here.
    printf("Matrix1:\n");
    printArray(matrix1, n);

    printf("Matrix2:\n");
    printArray(matrix2, n);

    // (5) Call matMult to multiply the 2 arrays here.
    int **resultMatrix = matMult(matrix1, matrix2, n);

    // (6) Call printArray to print out resulting array here.
    printf("\nResulting Matrix:\n");
    printArray(resultMatrix, n);

    return 0;
}
