#include <stdio.h>

int main() {
    int m = 10;
    int n = 5;

    int result;

    result = m + n;
    
    printf("%d\n", result);

    return 0;
}
