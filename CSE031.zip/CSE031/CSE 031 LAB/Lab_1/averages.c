#include <stdio.h>
// double averagetotal(double even, double odd, int count)
// {
//     double average =0;
//     average = (even+odd)/(count-1); //count -1 to fix error of
//     return average;
// }

int digitadder(int digit)
{
    int sum = 0;
    int d = digit;
    while (d != 0)
    {
        sum = sum + d % 10;
        d = d / 10;
    }
    return sum;
}
double averagetotaleven(double even, int counteven)
{
    double average = 0;
    average = (even) / (counteven - 1);
    return average;
}
double averagetotalodd(double odd, int countodd)
{
    double average = 0;
    average = (odd) / (countodd);
    return average;
}
int main()
{
    int numbers = 1;
    double average = 0;
    int evencount = 0;
    int oddcount = 0;
    int count = 1;
    double sum_even = 0;
    double sum_odd = 0;
    int sum = 0;
    int holder = 0;
    while (numbers != 0)
    {
        if (count==1)
        {
            printf("Enter the %dst number: ", count);
        }
        // else if (count>=2 && count <4)
        // {
        
        // }
        // else if (count>=2 && count <4)
        // {
        //     printf("Enter the %drd number: ", count);
        // }
        // else if (count>=5 && count <=10)
        // {
        //     printf("Enter the %dth number: ", count);
        // }
        // else if (count-(count-1)==1)
        // {
        //     printf("Enter the %dst number: ", count);
        // }
        // else if (count-(count-2)>=2 && count-(count-3) <4)
        // {
        //     printf("Enter the %drd number: ", count);
        // }
        // else if (count-(count-5)>=5 && count-(count-10) <=10)
        // {
        //     printf("Enter the %dst number: ", count);
        // }
        
        
        scanf("%d", &numbers); // read an integer from the user input and store it in the variable named "numbers.
        holder = digitadder(numbers);
        count++;
        if (holder % 2 == 0)
        {
            sum_even = sum_even + numbers;
            evencount++;
        }
        else
        {
            sum_odd = sum_odd + numbers;
            oddcount++;
        }
    }
    if (numbers == 0 && count == 2)
    {
        printf("There is no average to compute.");
    }
    else if (evencount-1 == 0)
    {
        printf("Average of input values whose digits sum up to an odd number: %.2lf\n", averagetotalodd(sum_odd, oddcount));
    }
    else if (oddcount == 0)
    {
        printf("Average of input values whose digits sum up to an even number: %.2lf\n", averagetotaleven(sum_even, evencount));
    }
    else
    {
        // average = averagetotal(sum_even,sum_odd,count);
        printf("Average of input values whose digits sum up to an even number: %.2lf\n", averagetotaleven(sum_even, evencount));
        printf("Average of input values whose digits sum up to an odd number: %.2lf\n", averagetotalodd(sum_odd, oddcount));
        // printf("Average of numbers: %.2lf\n",average);
    }

    return 0;
}
