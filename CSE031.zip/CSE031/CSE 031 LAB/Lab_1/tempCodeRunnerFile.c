    if (count)
    {
        printf("Enter the %dst number: ", count);
    }