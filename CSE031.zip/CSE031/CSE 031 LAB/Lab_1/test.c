void main(); {
int *p, x = 5, y; // init
y = *(p = &x) + 1;
int z;
flip-sign(p);
printf("x=%d, y=%d, *p=%d\n", x, y, p);
}
flip-sign(int *n){*n = -(*n)
}