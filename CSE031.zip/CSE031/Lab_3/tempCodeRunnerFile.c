    // for (i = 0; i < n - 1; i++) {
    //     for(j = 0; j < n - 1; j++) {
    //         if(s_arr[j] > s_arr[j + 1]) {
    //             temp = s_arr[j + 1];
    //             s_arr[j + 1] = s_arr[j];
    //             s_arr[j] = temp;
    //         }
    //     }
    // }