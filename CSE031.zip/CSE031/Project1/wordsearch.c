#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// Declarations of the two functions you will implement
// Feel free to declare any helper functions or global variables
void printPuzzle(char **arr);
void searchPuzzle(char **arr, char *word);
void printResult();
int bSize;

// Main function, DO NOT MODIFY
int main(int argc, char **argv)
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <puzzle file name>\n", argv[0]);
        return 2;
    }
    int i, j;
    FILE *fptr;

    // Open file for reading puzzle
    fptr = fopen(argv[1], "r");
    if (fptr == NULL)
    {
        printf("Cannot Open Puzzle File!\n");
        return 0;
    }

    // Read the size of the puzzle block
    fscanf(fptr, "%d\n", &bSize);

    // Allocate space for the puzzle block and the word to be searched
    char **block = (char **)malloc(bSize * sizeof(char *));
    char *word = (char *)malloc(20 * sizeof(char));

    // Read puzzle block into 2D arrays
    for (i = 0; i < bSize; i++)
    {
        *(block + i) = (char *)malloc(bSize * sizeof(char));
        for (j = 0; j < bSize - 1; ++j)
        {
            fscanf(fptr, "%c ", *(block + i) + j);
        }
        fscanf(fptr, "%c \n", *(block + i) + j);
    }
    fclose(fptr);

    printf("Enter the word to search: ");
    scanf("%s", word);

    // Print out original puzzle grid
    printf("\nPrinting puzzle before search:\n");
    printPuzzle(block);

    // Call searchPuzzle to the word in the puzzle
    searchPuzzle(block, word);

    return 0;
}

void printPuzzle(char **arr)
{
    // This function will print out the complete puzzle grid (arr).
    // It must produce the output in the SAME format as the samples
    // in the instructions.
    // Your implementation here...
    for (int i = 0; i < bSize; i++)
    {
        for (int j = 0; j < bSize; j++)
        {
            printf("%c ", *(*(arr + i) + j));
        }
        printf("\n");
    }
}

// bool function to check neighbors and recursively check if the path of neighbors is valid and finds the word
// x and y are coordinates, int** path is the search path that gets printed out and index is the index of each character in the word we are looking for.

// helper function------------------------------------------------------------------------------------------------
bool is_Word_found(char **arr, int x, int y, char *word, int **path, int index)
{
    if (*(word + index) == '\0') // \0 is null terminator
    {
        return true; // End, and the word is fully found
    }

    // Initialize row and column bounds
    int rows = bSize;
    int cols = strlen(*(arr + 0));

    // Check if out of bounds or already visited
    if (x < 0 || y < 0 || x >= rows || y >= cols || *(*(path + x) + y) < 0)
    {
        return false;
    }

    // Check if match
    if (*(*(arr + x) + y) != *(word + index))
    {
        return false; // If it doesn't match.
    }

    int *pathCell = &*(*(path + x) + y); // Get a pointer to the cell in the 'path' 2D array at coordinates (x, y).

    // Check if the path cell is zero or not
    if (*pathCell == 0)
    {
        // If zero, set it to index + 1
        *pathCell = index + 1;
    }

    // Use a negative value as a marker to indicate the cell has been visited
    *pathCell = -(*pathCell); //FIXED

    // Array of directional offsets: {-1, 0, 1} for both x and y.
    int directional_offsets[] = {-1, 0, 1};
    bool found = false;

    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            int newX = x + *(directional_offsets + i);
            int newY = y + *(directional_offsets + j);

            if (newX == x && newY == y)
            {
                continue; // Skip the current cell.
            }

            // Advance to the next character in the 'word' for the recursive search.
            found = is_Word_found(arr, newX, newY, word, path, index + 1);

            if (found)
            {
                break; // Word found and finish as we only need 1 path
            }
        }
        if (found)
        {
            break; // Word found in one path.
        }
    }

    // Unmark current cell
    *pathCell = -(*pathCell);

    if (!found)
        *pathCell = 0; // Unmark current cell.

    return found;
}

//TDLR: When a cell is found its marked as neg so if we ever loop around in a zigzag we unmark and ignore so we never overlap.
//----------------------------------------------------------------------------- ------------------------
// helper function-----------------------------------------------------------------------------
char Upper(char character)
{
    if (character >= 'a' && character <= 'z') // check if >97 but less than 122 so its lowercase
    {
        return character - ('a' - 'A'); // 97-65 =32 to convert to upper case
    }
    return character; // if good as is then we just return.
}

//------------------------------------------------------------------------------------------------
void searchPuzzle(char **arr, char *word)
{
    // This function checks if arr contains the search word. If the
    // word appears in arr, it will print out a message and the path
    // as shown in the sample runs. If not found, it will print a
    // different message as shown in the sample runs.

    // Convert lower case letters to uppercase
    for (int i = 0; *(word + i) != '\0'; i++) //loop through all
    {
        *(word + i) = Upper(*(word + i));
    }

    // Initialize and fill arr1 with 0's this is just the setup make the template search layout
    int **arr1 = (int **)malloc(bSize * sizeof(int *));
    for (int i = 0; i < bSize; i++)
    {
        *(arr1 + i) = (int *)malloc(bSize * sizeof(int));
        for (int j = 0; j < bSize; j++)
        {
            *(*(arr1 + i) + j) = 0; // setting to zeros here
        }
    }
    int count = 0;
    bool Word_Found = false;

    // Search for the word in the puzzle
    for (int i = 0; i < bSize; i++)
    {
        for (int j = 0; j < bSize; j++)
        {
            // Check to see if the word is found starting at index 0 for char* word
            if (is_Word_found(arr, i, j, word, arr1, 0) && count == 0)
            {
                count++;
                Word_Found = true; // set it to true for next if outside here
                printf("\n");
                printf("Word found!\n");
                printf("Printing the search path:\n");

                // Print search path
                for (int row = 0; row < bSize; row++)
                {
                    for (int col = 0; col < bSize; col++)
                    {
                        printf("%d\t", *(*(arr1 + row) + col));
                    }
                    printf("\n");
                }
            }
        }
    }
    if (Word_Found== false)
    {
        printf("\n");
        printf("Word not found!");
    }
    // Free mem
    for (int i = 0; i < bSize; i++)
    {
        free(*(arr1 + i));
    }
    free(arr1);
}