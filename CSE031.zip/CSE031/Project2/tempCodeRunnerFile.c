int calcSum(int *arr, int len)
{
    if (len <= 0)
        return 0;
    return (calcSum(arr, len - 1) + arr[len - 1]);
}