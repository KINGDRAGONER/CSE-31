#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int size;                        // Variable to record the size of the original array arr
int evenCount = 0, oddCount = 0; // Variables to record the sizes of new arrays arr_even and arr_odd
int *arr;                        // Dynamically allocated original array with #elements = size
int *arr_even;                   // Dynamically allocated array with #elements = #even elements in arr (evenCount)
int *arr_odd;                    // Dynamically allocated array with #elements = #odd elements in arr (oddCount)
char *str1 = "Original array's contents: ";
char *str2 = "Contents of the new array containing even elements from the original: ";
char *str3 = "Contents of the new array containing odd elements from the original: ";

// DO NOT change the definition of the printArr function when it comes to
// adding/removing/modifying the function parameters, or changing its return
// type.
void printArr(int *a, int size, char *prompt)
{
    printf("\n");         // Print a newline character to separate the output.
    printf("%s", prompt); // Print the custom prompt.

    if (size == 0)
    {
        printf("empty"); // If the array size is 0, print "empty" to indicate it's empty.
    }
    else
    {
        // If the array is not empty, loop through its elements.
        for (int i = 0; i < size; i++)
        {
            printf("%d ", *(a + i)); // Print each element of the array followed by a space.
        }
    }
}

// DO NOT change the definition of the arrCopy function when it comes to
// adding/removing/modifying the function parameters, or changing its return
// type.
void arrCopy()
{
    // Allocate memory for the 'arr_even' and 'arr_odd' arrays based on their respective sizes.
    arr_even = (int *)malloc(evenCount * sizeof(int));
    arr_odd = (int *)malloc(oddCount * sizeof(int));

    // Initialize index variables for tracking the positions in 'arr_even' and 'arr_odd'.
    int evenIndex = 0;
    int oddIndex = 0;

    // Loop through the original 'arr' array to separate even and odd numbers.
    for (int i = 0; i < size; i++)
    {
        // Check if the current element in 'arr' is even.
        if (*(arr + i) % 2 == 0)
        {
            // If it's even, copy it to 'arr_even' at the current 'evenIndex'.
            *(arr_even + evenIndex) = *(arr + i);
            evenIndex++;
        }
        else
        {
            // If it's odd, copy it to 'arr_odd' at the current 'oddIndex'.
            *(arr_odd + oddIndex) = *(arr + i);
            oddIndex++;
        }
    }
}

int main()
{
    printf("Enter the size of array you wish to create: ");
    scanf("%d", &size);

    // Dynamically allocate memory for arr (of appropriate size)
    arr = (int *)malloc(size * sizeof(int));

    // Ask the user to input the content of arr and compute evenCount and oddCount
    for (int i = 0; i < size; i++)
    {
        printf("Enter array element #%d: ", i + 1);
        scanf("%d", &*(arr + i));
        if (*(arr + i) % 2 == 0)
        {
            evenCount++;
        }
        else
        {
            oddCount++;
        }
    }

    // Dynamically allocate memory for arr_even and arr_odd (of appropriate size)
    arrCopy();

    /*************** YOU MUST NOT MAKE CHANGES BEYOND THIS LINE! ***********/

    // Print original array
    printArr(arr, size, str1);

    // Print new array containing even elements from arr
    printArr(arr_even, evenCount, str2);

    // Print new array containing odd elements from arr
    printArr(arr_odd, oddCount, str3);

    return 0;
}