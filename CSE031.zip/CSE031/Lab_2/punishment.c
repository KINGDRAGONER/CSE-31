#include <stdio.h>

int main()
{
    int count_repitions;
    int line_num_typo;

    printf("Enter the repetition count for the punishment phrase: ");
    scanf("%d", &count_repitions); //basically cin >>
    printf("\n");

    while (count_repitions <= 0)
    {
        printf("You entered an invalid value for the repetition count! Please re-enter: ");
        scanf("%d", &count_repitions);
    }

    printf("Enter the line where you want to insert the typo: ");
    scanf("%d", &line_num_typo);
    printf("\n");

    while (line_num_typo <= 0 || line_num_typo > count_repitions)
    {
        printf("You entered an invalid value for the typo placement! Please re-enter: ");
        scanf("%d", &line_num_typo);
    }

    for (int i = 1; i <= count_repitions; i++)
    {
        if (i == line_num_typo) //if i ==line_num_typo
        {
            printf("Cading wiht is C avesone!\n");
        }
        else
        {
            printf("Coding with C is awesome!\n");
        }
    }

    return 0;
}
