#include <stdio.h>
int main()
{
    int x, y, *px, *py;
    x=2;
    int arr[10];
    arr[0]=23;
    printf("x=%d,y=%d,arr=%d\n",x,y,arr[0]);
    px = &x;
    px = &y;

    printf("px=%p\npy=%p\n",&x,&y);
    int *ptr = arr;
    for (int i = 0; i < 10; i++) {
        printf("%d\n", *ptr);
        ptr++;  
  }
//Q7
    printf("Address of arr[0]:%p\n", &arr[0]);
    printf("Address of arr: %p\n", arr);
//Q8
    printf("Address of arr: %p\n", &arr);
    return 0; 
}