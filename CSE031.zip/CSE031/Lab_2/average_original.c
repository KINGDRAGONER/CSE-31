#include <stdio.h>

/*
    Read a set of values from the user.
    Store the sum in the sum variable and return the number of values read.
*/

// You CANNOT declare any global variables.
// You CANNOT change the definition of the read_values function when it comes to 
// adding/removing function parameters, or changing its return type.
int read_values(double sum) { //to update sum use *sun
  int values = 0, input = 0;
  sum = 0; //*sum
  printf("Enter input values (enter 0 to finish):\n");
  scanf("%d", &input);
  while(input != 0) {
    values++; // why even?
    sum += input; //*sum
    scanf("%d", &input); //problem
  }
  return values;
}

int main() {
  double sum = 0;
  int values; // not initialized
  values = read_values(sum); // make &sum
  printf("\nAverage: %g\n", sum/values); // Hint: How do we ensure that sum is updated here AFTER read_value manipulates it?
  return 0;
}

